package dao;

import java.sql.*;


import java.util.ArrayList;
import java.util.List;

import entity.Eshop;
//#85949d
//#2192d3
public class EshopDao {    //执行对商品数据库的操作
	public List<Eshop> query(){   //顺序查询全部商品信息
		Connection c=null;   
		List<Eshop> list =new ArrayList<Eshop>();
		try{
			c=DBConnection.getConnection();
			String sql="select * from Eshop order by no";
			PreparedStatement pst=c.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				Eshop eshop =new Eshop();
				eshop.setNo(rs.getInt("No"));
				eshop.setName(rs.getString("name"));
				eshop.setPrice(rs.getFloat("price"));
				eshop.setAmount(rs.getInt("amount"));
				eshop.setType(rs.getString("type"));
				eshop.setPlace(rs.getString("place"));
				list.add(eshop);
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public boolean insert(Eshop eshop){    //添加商品信息
		Connection c=null ;      ;
		try{
			c=DBConnection.getConnection();
			String sql="insert into Eshop(no,name,price,amount,type,place) values (?,?,?,?,?,?)";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,eshop.getNo());
			pst.setString (2,eshop.getName());
			pst.setFloat(3,eshop.getPrice());
			pst.setInt(4,eshop.getAmount());
			pst.setString(5,eshop.getType());
			pst.setString(6,eshop.getPlace());
			pst.execute();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public Eshop query(int no){   //查询商品
		Connection c=null ;      ;
		try{
			c=DBConnection.getConnection();
			String sql="select * from Eshop where no=?";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,no);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				Eshop eshop=new Eshop();
				eshop.setNo(rs.getInt("no"));
				eshop.setName(rs.getString("name"));
				eshop.setPrice(rs.getFloat("price"));
				eshop.setAmount(rs.getInt("amount"));
				eshop.setType(rs.getString("type"));
				eshop.setPlace(rs.getString("place"));
				return eshop;
			}else{
				return null;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public boolean deleteByNo(int no){    //删除商品
		Connection c=null;
		try{
			c=DBConnection.getConnection();
			String sql="delete from Eshop where no=?";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,no);
			pst.execute();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			DBConnection.closeConnection(c);
		}
	}
	public boolean updateByNo(Eshop eshop,int no){   //更新商品
		 	Connection c=null;
		 	try{
		 		c=DBConnection.getConnection();
				String sql="update eshop set no=?,name=?,price=?,amount=?,type=?,place=? where no=?";
				PreparedStatement pst=c.prepareStatement(sql);
				pst.setInt(1, eshop.getNo());
				pst.setString(2, eshop.getName());
				pst.setFloat(3, eshop.getPrice());
				pst.setInt(4, eshop.getAmount());
				pst.setString(5, eshop.getType());
				pst.setString(6, eshop.getPlace());	
				pst.setInt(7,no);
				pst.execute();	
				return true;		 	
		 	}catch(Exception e){
		 		e.printStackTrace();
		 		return false;
		 	}finally{
		 		DBConnection.closeConnection(c);
		 	}
	}
	
	
		public static void main(String args[]){
		EshopDao dao=new EshopDao();
		List<Eshop> list=dao.query();
		System.out.println("闀垮害鏄�"+list.size());
		//EshopDao dao=new EshopDao();
//		Eshop eshop =new Eshop();
	
		//boolean b=Eshopdao.update(Eshop,11);
//		boolean b=dao.insert(eshop);
		//System.out.println("update  "+b);*/
		//Eshop Eshop=dao.query(1);
		
		//boolean c=dao.update(Eshop, 17);
		
		//boolean c=dao.delete(10);
//		System.out.print(b);
	
	}
}
