package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dao.UserDao;
import entity.User;
public class UserDao  {    //执行对用户数据库的操作
	
	public User ByUserName(String uname) {   //通过用户名查找用户
		Connection con=null;
		try{
			con=DBConnection.getConnection();
			String sql="select * from user where uname=?";
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, uname);
			ResultSet rs=pst.executeQuery();
			if(rs.next()==false){
				return null;
			}else{
				User user=new User();
				user.setId(rs.getInt("id"));
				user.setUname(rs.getString("uname"));
				user.setPwd(rs.getString("pwd"));
				user.setStatus(rs.getString("status"));
				user.setScore(rs.getFloat("score"));
				return user;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(con);
		}
		
	}
	
	public List<User> query(){   //顺序查询全部用户信息
		Connection c=null;   
		List<User> list =new ArrayList<User>();
		try{
			c=DBConnection.getConnection();
			String sql="select * from User order by id";
			PreparedStatement pst=c.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				User user =new User();
				user.setId(rs.getInt("id"));
				user.setUname(rs.getString("uname"));
				user.setPwd(rs.getString("pwd"));
				user.setStatus(rs.getString("status"));
				user.setScore(rs.getFloat("score"));
				list.add(user);
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public boolean insert(User user){    //添加用户信息
		Connection c=null ;      ;
		try{
			c=DBConnection.getConnection();
			String sql="insert into User(id,uname,pwd,status,score) values (?,?,?,?,?)";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,user.getId());
			pst.setString (2,user.getUname());
			pst.setString(3,user.getPwd());
			pst.setString(4,user.getStatus());
			pst.setFloat(5,user.getScore());
			pst.execute();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public User query(int id){   //查询用户
		Connection c=null ;      ;
		try{
			c=DBConnection.getConnection();
			String sql="select * from User where id=?";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,id);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				User user=new User();
				user.setId(rs.getInt("id"));
				user.setUname(rs.getString("uname"));
				user.setPwd(rs.getString("pwd"));
				user.setStatus(rs.getString("status"));
				user.setScore(rs.getFloat("score"));
				return user;
			}else{
				return null;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			DBConnection.closeConnection(c);
		}
		
	}
	
	public boolean deleteById(int id){    //删除用户
		Connection c=null;
		try{
			c=DBConnection.getConnection();
			String sql="delete from User where id=?";
			PreparedStatement pst=c.prepareStatement(sql);
			pst.setInt(1,id);
			pst.execute();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			DBConnection.closeConnection(c);
		}
	}
	public boolean updateById(User user,int id){   //更新用户
		 	Connection c=null;
		 	try{
		 		c=DBConnection.getConnection();
				String sql="update user set id=?,uname=?,pwd=?,status=?,score=? where id=?";
				PreparedStatement pst=c.prepareStatement(sql);
				pst.setInt(1, user.getId());
				pst.setString(2, user.getUname());
				pst.setString(3, user.getPwd());
				pst.setString(4,user.getStatus());
				pst.setFloat(5,user.getScore());
				pst.setInt(6,id);
				pst.execute();	
				return true;		 	
		 	}catch(Exception e){
		 		e.printStackTrace();
		 		return false;
		 	}finally{
		 		DBConnection.closeConnection(c);
		 	}
	}
	
	public static void main(String[] args) {
		UserDao u=new UserDao();
		User user=u.ByUserName("admin");
		System.out.println(user.getPwd());
		List<User> list=u.query();
		System.out.println("闀垮害鏄�"+list.size());
	}	
}
