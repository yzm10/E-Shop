package servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EshopDao;
import entity.Eshop;


/**
 * Servlet implementation class AddPost
 */
public class AddPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		int no=Integer.parseInt(request.getParameter("no"));
		String name=request.getParameter("name");
		float price=Float.parseFloat(request.getParameter("price"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		String type=request.getParameter("type");
		String place=request.getParameter("place");
		Eshop eshop=new Eshop();
		eshop.setNo(no);
		eshop.setName(name);
		eshop.setPrice(price);
		eshop.setAmount(amount);
		eshop.setType(type);
		eshop.setPlace(place);
		EshopDao dao=new EshopDao();
		
		boolean b=dao.insert(eshop);
		System.out.println("ok");
		if(b==true){
			request.getRequestDispatcher("AdminPost").forward(request, response);
		}else{
			response.sendRedirect("add.jsp");
		}
		
	}

}
