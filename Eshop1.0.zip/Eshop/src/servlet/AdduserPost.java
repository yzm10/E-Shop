package servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import entity.User;


/**
 * Servlet implementation class AdduserPost
 */
public class AdduserPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdduserPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		int id=Integer.parseInt(request.getParameter("id"));
		String uname=request.getParameter("uname");
		String pwd=request.getParameter("pwd");
		String status=request.getParameter("status");
		float score=Float.parseFloat(request.getParameter("score"));
		User user=new User();
		user.setId(id);
		user.setUname(uname);
		user.setPwd(pwd);
		user.setStatus(status);
		user.setScore(score);
		UserDao dao=new UserDao();
		
		boolean b=dao.insert(user);
		System.out.println("ok");
		if(b==true){
			request.getRequestDispatcher("BossPost").forward(request, response);
		}else{
			response.sendRedirect("adduser.jsp");
		}
		
	}

}
