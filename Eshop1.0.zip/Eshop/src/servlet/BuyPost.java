package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.EshopDao;
import entity.Eshop;

/**
 * Servlet implementation class BuyPost
 */
public class BuyPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("更改");
		request.setCharacterEncoding("utf-8");
		int no=Integer.parseInt(request.getParameter("no"));
		String name=request.getParameter("name");
		float price=Float.parseFloat(request.getParameter("price"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		String type=request.getParameter("type");
		String place=request.getParameter("place");
		
		EshopDao dao=new EshopDao();
		Eshop eshop=dao.query(no);
		
		eshop.setNo(no);
		eshop.setName(name);
		eshop.setPrice(price);
		eshop.setAmount(eshop.getAmount()-amount);  //ȡ����Ʒ
		eshop.setType(type);
		eshop.setPlace(place);
		
		boolean b=dao.updateByNo(eshop, no);
		System.out.println("ok"+b);
		if(b==true){
			HttpSession session=request.getSession();   //�ۼӽ��
			session.setAttribute("sum", (Float)session.getAttribute("sum") + price*amount);
			request.getRequestDispatcher("MainPost").forward(request, response);
		}else{
			response.sendRedirect("buy.jsp");
		}
		
	}

}
